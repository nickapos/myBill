#!/bin/bash
java -jar myBill.jar
